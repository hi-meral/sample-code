Running Server :

1. Change host address in index.php and server.php

2. Go to your shell command-line interface

3. type: 
	php -q c:\path\server.php

4. Using browser, navigate to index.php location to open chat page, have fun!


@Tutorial : http://www.sanwebe.com/2013/05/chat-using-websocket-php-socket
@License : http://opensource.org/licenses/MIT



---------------------------


php should be a command

[ Computer > properties > Advanced system setting > Environment variable > User variable for Meral > New > variable : path, value:D:\wamp\bin\php\php5.5.12 ]

open cmd

go to this folder path

- cd wamp\www\socket

- php server.php

this will run a script on command line

---------------------------
